#!/usr/bin/env python

import time
import rediswq   #引入上面创建的python程序

host="redis"   #传入主机地址，就是svc名称
q = rediswq.RedisWQ(name="job2", host=host)  #redis工作队列名称
print("Worker with sessionID: " +  q.sessionID())
print("Initial queue state: empty=" + str(q.empty()))
while not q.empty():
  item = q.lease(lease_secs=10, block=True, timeout=2) 
  if item is not None:
    itemstr = item.decode("utf-8")
    print("Working on " + itemstr)
    time.sleep(10) # Put your actual work here instead of sleep.
    q.complete(item)
  else:
    print("Waiting for work")
print("Queue empty, exiting")
