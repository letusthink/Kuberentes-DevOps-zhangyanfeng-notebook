This is test ArgoCD YAML
