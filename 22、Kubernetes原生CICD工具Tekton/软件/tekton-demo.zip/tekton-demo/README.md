# tekton-demo

《Tekton 初体验》公开课，地址：[https://youdianzhishi.com/web/course/1014/1475](https://youdianzhishi.com/web/course/1014/1475)

文档：[http://my-oss-testing.oss-cn-beijing.aliyuncs.com/course/tekton/Tekton%20%E5%88%9D%E4%BD%93%E9%AA%8C.pdf](http://my-oss-testing.oss-cn-beijing.aliyuncs.com/course/tekton/Tekton%20%E5%88%9D%E4%BD%93%E9%AA%8C.pdf)
