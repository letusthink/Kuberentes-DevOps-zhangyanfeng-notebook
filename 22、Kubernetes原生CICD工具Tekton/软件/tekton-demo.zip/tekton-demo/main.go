package main

import "fmt"

func sum(a, b int) int {
	return a + b
}

func main() {
	fmt.Println("Sum: ", sum(1, 2))
}
